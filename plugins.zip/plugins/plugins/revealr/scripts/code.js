
(function (window, undefined) {
  window.Asc.plugin.init = function () {
      let self = this;
      const placeholders = document.querySelectorAll('.placeholder-item');

      placeholders.forEach(function (item) {
          if (!item.dataset.listenerAdded) {
              item.addEventListener('click', function (e) {
                  Asc.scope.eventData = {
                      targetInnerText: e.target.innerText
                  };

                  self.callCommand(function () {
                      var eventData = Asc.scope.eventData;
                      var oDocument = Api.GetDocument();
                      var oParagraph = Api.CreateParagraph();
                      var oRun = Api.CreateRun();

                      oRun.AddText(eventData.targetInnerText);
                      oParagraph.AddElement(oRun);

                      // Use InsertContent to insert the text at the current cursor position
                      // and preserve the text formatting
                      oDocument.InsertContent([oParagraph], true, {"KeepTextOnly": true});

                      delete Asc.scope.eventData;
                  }, false);
              });
              item.dataset.listenerAdded = 'true';
          }
      });
  };

  window.Asc.plugin.button = function (id) {};
})(window, undefined);








document.addEventListener('DOMContentLoaded', function () {
  const placeholderDemoInput = document.querySelector('#placeholder-demo');
  const placeholderInput = document.querySelector('#placeholder-input');
  let createPlaceholder = false

  placeholderInput.addEventListener('input', function (e) {
    if (!e.target.value) {
      placeholderDemoInput.value = '';
      return;
    }
    placeholderDemoInput.value = `<<${e.target.value}>>`;
  });
  const data = new FormData();
  data.append('Token', window.token);
  data.append('ClientId', window.clientId)
  data.append('FinalSiteId', window.finalSideId)
  window.axios({
    url: `${window.linkk}/api/Collateral/GetListPlaceholder`,
    method: 'POST',
    data: data
  }).then(function (res) {
    console.log(res);
  })
  function addPlaceholderItem(id, text) {
    // Create the <li> element
    var listItem = document.createElement('li');
    listItem.className = 'e-list-item placeholder-item e-level-1';
    listItem.setAttribute('role', 'listitem');
    listItem.setAttribute('data-uid', id);
    listItem.setAttribute('title', 'Drag or click the field to insert.');
    listItem.setAttribute('draggable', 'true');
    listItem.id = 'listview_' + id;
    listItem.setAttribute('tabindex', '-1');

    // Create the inner div
    var div = document.createElement('div');
    div.className = 'e-text-content';
    div.setAttribute('role', 'presentation');

    // Create the span for text
    var span = document.createElement('span');
    span.className = 'e-list-text';
    span.textContent = text;

    // Append the span to the div, and the div to the list item
    div.appendChild(span);
    listItem.appendChild(div);

    // Append the list item to the ul
    document.getElementById('placeholder-list').appendChild(listItem);
  }

  data.length > 0 &&
    data.forEach(function (item) {
      addPlaceholderItem(item.Id, item.Slug);
    });
   createPlaceholder ? document.querySelector("#dialog").style.display = "block" : document.querySelector("#dialog").style.display = "none";
   createPlaceholder ? document.querySelector("#cancelPlaceholderButton").style.display = "block" : document.querySelector("#cancelPlaceholderButton").style.display = "none";
  document.querySelector("#createPlaceholderButton").addEventListener("click", function () {  
    createPlaceholder = !createPlaceholder;
    const list = document.querySelector(".e-list-container");
    const form  = document.querySelector("#dialog");
    const cancelPlaceholderButton = document.querySelector("#cancelPlaceholderButton");
    if (createPlaceholder) {
      document.querySelector("#createPlaceholderButton").innerText = "Create";
      document.querySelector("#placeholder-search").style.display = "none";
      form.style.display = "block";
      list.style.display = "none";
      cancelPlaceholderButton.style.display = "block";
      
    } else {
      document.querySelector("#createPlaceholderButton").innerText = "Create Placeholder";
      form.style.display = "none";
      list.style.display = "block";
      cancelPlaceholderButton.style.display = "none";
      addPlaceholderItem(new Date(), `<<${placeholderInput.value}>>`)
      document.querySelector("#placeholder-search").style.display = "block";

    }
  });

  document.querySelector("#cancelPlaceholderButton").addEventListener("click", function () {
    createPlaceholder = !createPlaceholder;
    const list = document.querySelector(".e-list-container");
    const form  = document.querySelector("#dialog");
    const cancelPlaceholderButton = document.querySelector("#cancelPlaceholderButton");
    if (createPlaceholder) {
      form.style.display = "block";
      list.style.display = "none";
      cancelPlaceholderButton.style.display = "block";
      document.querySelector("#placeholder-search").style.display = "none";

    } else {
      document.querySelector("#createPlaceholderButton").innerText = "Create Placeholder";
      form.style.display = "none";
      list.style.display = "block";
      cancelPlaceholderButton.style.display = "none";
      document.querySelector("#placeholder-search").style.display = "block";

    }
  });

});
